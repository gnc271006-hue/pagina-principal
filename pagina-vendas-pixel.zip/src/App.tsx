import React, { useState } from 'react';
import { TopNoticeBar } from './components/TopNoticeBar';
import { Hero } from './components/Hero';
import { GallerySection, GalleryItemData } from './components/GallerySection';
import { ProblemSection } from './components/ProblemSection';
import { TargetAudienceSection } from './components/TargetAudienceSection';
import { ProductPresentationSection } from './components/ProductPresentationSection';
import { BonusSection } from './components/BonusSection';
import { OfferSection } from './components/OfferSection';
import { GuaranteeSection } from './components/GuaranteeSection';
import { DeliverySection } from './components/DeliverySection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { Footer } from './components/Footer';
import { LightboxModal } from './components/LightboxModal';

export function App() {
  const [selectedImage, setSelectedImage] = useState<{ src: string; alt: string } | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#142B4A]">
      {/* Top Notice Bar */}
      <TopNoticeBar />

      <main className="flex-1">
        {/* Section 1 — Hero */}
        <Hero 
          onImageClick={() => setSelectedImage({
            src: '/Guia exercícios para o ronco 2.jpeg',
            alt: 'Guia Ilustrado Exercícios para o Ronco'
          })}
        />

        {/* Section 2 — Galeria dos Mapas Mentais */}
        <GallerySection 
          onSelectImage={(item: GalleryItemData) => setSelectedImage({
            src: item.src,
            alt: item.alt
          })}
        />

        {/* Section 3 — Identificação do Problema */}
        <ProblemSection />

        {/* Section 4 — Para Quem Foi Feito */}
        <TargetAudienceSection />

        {/* Section 5 — Apresentação do Produto */}
        <ProductPresentationSection />

        {/* Section 6 — Os Três Bônus */}
        <BonusSection />

        {/* Section 7 — Oferta */}
        <OfferSection />

        {/* Section 8 — Garantia */}
        <GuaranteeSection />

        {/* Section 9 — Como Você Recebe o Material */}
        <DeliverySection />

        {/* Section 10 — Perguntas Frequentes */}
        <FaqSection />

        {/* Section 11 — CTA Final */}
        <FinalCtaSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Image inspection lightbox modal */}
      <LightboxModal
        imageSrc={selectedImage?.src || null}
        imageAlt={selectedImage?.alt}
        onClose={() => setSelectedImage(null)}
      />
    </div>
  );
}

export default App;
