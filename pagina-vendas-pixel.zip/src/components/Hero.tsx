import React from 'react';
import { Lock, ChevronDown } from 'lucide-react';
import { scrollToOffer } from '../utils/checkout';

interface HeroProps {
  onImageClick?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onImageClick }) => {
  return (
    <section className="bg-white pt-8 pb-16 md:pt-12 md:pb-20 border-b border-slate-100">
      <div className="max-w-5xl mx-auto px-4 text-center">
        {/* Headline with Highlighter Effect */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-[42px] font-extrabold text-[#142B4A] max-w-4xl mx-auto tracking-tight leading-[1.3]">
          “Quando o ronco atrapalha suas noites,{' '}
          <span className="highlighter-marker">
            até o descanso de quem você ama pode ser afetado.
          </span>”
        </h1>

        {/* Short & Objective Subheadline */}
        <p className="mt-4 md:mt-5 text-base sm:text-lg text-[#416A98] max-w-2xl mx-auto leading-relaxed">
          Exercícios práticos e orientações simples para incluir na sua rotina noturna e observar seus hábitos com tranquilidade.
        </p>

        {/* Main Product Image */}
        <div className="mt-8 md:mt-10 max-w-3xl mx-auto">
          <div 
            onClick={onImageClick}
            className="group relative bg-white rounded-2xl p-2 sm:p-4 shadow-xl border border-slate-200/80 cursor-pointer overflow-hidden transition-all hover:shadow-2xl hover:border-[#416A98]"
          >
            <img
              src="/Guia exercícios para o ronco 2.jpeg"
              alt="Guia Ilustrado Exercícios para o Ronco - Material Educativo Digital"
              className="w-full h-auto object-contain rounded-xl max-h-[580px] mx-auto group-hover:scale-[1.01] transition-transform duration-300"
              loading="eager"
            />
            <div className="absolute inset-0 bg-[#080F1D]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <span className="bg-white/95 text-[#142B4A] text-xs sm:text-sm font-bold px-4 py-2 rounded-xl shadow-md backdrop-blur-xs">
                Clique para ampliar imagem
              </span>
            </div>
          </div>
        </div>

        {/* Pill Button */}
        <div className="mt-8 flex flex-col items-center justify-center space-y-3">
          <button
            onClick={scrollToOffer}
            className="btn-pill-green text-base sm:text-lg px-9 sm:px-12 py-4.5 shadow-md hover:shadow-lg w-full sm:w-auto min-w-[280px]"
          >
            <span>Quero conhecer o material</span>
            <ChevronDown className="w-5 h-5 shrink-0" />
          </button>

          {/* Micro guarantee badge */}
          <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#416A98] pt-1">
            <Lock className="w-3.5 h-3.5 text-[#176447]" />
            <span>Compra 100% Segura · 7 dias de garantia</span>
          </div>
        </div>
      </div>
    </section>
  );
};
