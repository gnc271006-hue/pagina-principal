import React, { useRef, useState, useEffect } from 'react';
import { User, BedDouble, HeartHandshake, ChevronDown, Sparkles } from 'lucide-react';
import { scrollToOffer } from '../utils/checkout';

interface CardData {
  id: number;
  tag: string;
  icon: typeof User;
  title: string;
  desc: string;
  badge: string;
}

const CARDS: CardData[] = [
  {
    id: 1,
    tag: '01',
    icon: User,
    title: 'Para quem ronca',
    desc: 'Para pessoas que desejam conhecer exercícios e observar melhor seus hábitos relacionados ao ronco.',
    badge: 'Autocuidado e Consciência'
  },
  {
    id: 2,
    tag: '02',
    icon: BedDouble,
    title: 'Para quem divide o quarto',
    desc: 'Para quem convive com alguém que ronca e deseja conhecer práticas que podem ser incluídas na rotina.',
    badge: 'Convivência e Harmonia'
  },
  {
    id: 3,
    tag: '03',
    icon: HeartHandshake,
    title: 'Para casais',
    desc: 'Para casais que desejam buscar uma rotina noturna mais organizada e compreender melhor essa situação.',
    badge: 'Descanso a Dois'
  }
];

export const TargetAudienceSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [activeCardId, setActiveCardId] = useState<number | null>(null);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Check prefers-reduced-motion and screen size
  useEffect(() => {
    const mqMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mqMotion.matches);

    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);

    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Continuous bidirectional scroll tracker with smooth animation frame
  useEffect(() => {
    if (reducedMotion) return;

    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          if (containerRef.current) {
            const rect = containerRef.current.getBoundingClientRect();
            const totalScrollable = rect.height - window.innerHeight;

            if (totalScrollable > 0) {
              const currentProgress = Math.min(1, Math.max(0, -rect.top / totalScrollable));
              setProgress(currentProgress);
            }
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, [reducedMotion]);

  // Smooth Hermite cubic ease-in-out interpolation curve
  const smoothstep = (min: number, max: number, value: number) => {
    const x = Math.max(0, Math.min(1, (value - min) / (max - min)));
    return x * x * (3 - 2 * x);
  };

  /**
   * RIGID TIMELINE TO PREVENT PREMATURE OVERLAP:
   * 
   * [0.00 - 0.28]: Card 1 is alone, 100% visible, fully stabilized.
   *                 Card 2 and Card 3 have NOT started entering (opacity: 0).
   * 
   * [0.28 - 0.52]: Card 2 enters smoothly and reaches its stacked position.
   * [0.52 - 0.68]: Card 2 is completely in place, 100% visible and stabilized over Card 1.
   *                 Card 3 has STILL NOT started entering (opacity: 0).
   * 
   * [0.68 - 0.92]: Card 3 enters smoothly and reaches its stacked position.
   * [0.92 - 1.00]: Card 3 is completely in place, 100% visible and stabilized over Card 2.
   * 
   * Bidirectional: scrolling up reverses this exact timeline smoothly.
   */
  const p2 = smoothstep(0.28, 0.52, progress);
  const p3 = smoothstep(0.68, 0.92, progress);

  // Stack offsets
  const stepOffset = isMobile ? 44 : 56;

  // Card 1: Stays stable, slightly scales down as Cards 2 and 3 stack over it
  const card1Scale = 1 - p2 * 0.04 - p3 * 0.03; // 1.0 -> 0.96 -> 0.93
  const card1TranslateY = -p2 * (isMobile ? 4 : 6) - p3 * (isMobile ? 4 : 6);
  const card1Opacity = 1 - p3 * 0.08;

  // Card 2: Starts entering only after Card 1 is fully presented and stabilized
  const card2InitialY = isMobile ? 160 : 220;
  const card2TargetY = stepOffset;
  const card2CurrentY = card2InitialY - p2 * (card2InitialY - card2TargetY) - p3 * (isMobile ? 4 : 6);
  const card2Scale = 0.96 + p2 * 0.04 - p3 * 0.03; // 0.96 -> 1.0 -> 0.97
  const card2Opacity = p2;

  // Card 3: Starts entering only after Card 2 is fully presented and stabilized
  const card3InitialY = isMobile ? 180 : 240;
  const card3TargetY = stepOffset * 2;
  const card3CurrentY = card3InitialY - p3 * (card3InitialY - card3TargetY);
  const card3Scale = 0.95 + p3 * 0.05; // 0.95 -> 1.0
  const card3Opacity = p3;

  const getCardStyle = (id: number): React.CSSProperties => {
    if (reducedMotion) {
      return {};
    }

    const isFocused = activeCardId === id;

    if (id === 1) {
      return {
        transform: `translateY(${card1TranslateY}px) scale(${isFocused ? 1.02 : card1Scale})`,
        opacity: card1Opacity,
        zIndex: isFocused ? 50 : 10,
        transition: isFocused ? 'transform 0.25s ease, z-index 0.25s ease' : 'none',
        willChange: 'transform, opacity'
      };
    }

    if (id === 2) {
      return {
        transform: `translateY(${card2CurrentY}px) scale(${isFocused ? 1.02 : card2Scale})`,
        opacity: card2Opacity,
        visibility: p2 <= 0.01 ? 'hidden' : 'visible',
        pointerEvents: p2 <= 0.05 ? 'none' : 'auto',
        zIndex: isFocused ? 50 : 20,
        transition: isFocused ? 'transform 0.25s ease, z-index 0.25s ease' : 'none',
        willChange: 'transform, opacity'
      };
    }

    if (id === 3) {
      return {
        transform: `translateY(${card3CurrentY}px) scale(${isFocused ? 1.02 : card3Scale})`,
        opacity: card3Opacity,
        visibility: p3 <= 0.01 ? 'hidden' : 'visible',
        pointerEvents: p3 <= 0.05 ? 'none' : 'auto',
        zIndex: isFocused ? 50 : 30,
        transition: isFocused ? 'transform 0.25s ease, z-index 0.25s ease' : 'none',
        willChange: 'transform, opacity'
      };
    }

    return {};
  };

  return (
    <section 
      ref={containerRef}
      className={`relative bg-[#F8FAFC] border-b border-slate-200/80 ${
        reducedMotion ? 'py-16 md:py-24' : 'min-h-[230vh] sm:min-h-[250vh]'
      }`}
    >
      {/* Sticky Stage Container */}
      <div className={`${reducedMotion ? 'relative' : 'sticky top-12 sm:top-16'} max-w-4xl mx-auto px-4 py-8`}>
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#142B4A] bg-[#DCEBFA] px-3.5 py-1 rounded-full mb-2.5">
            <Sparkles className="w-3.5 h-3.5 text-[#416A98]" /> Identificação e Roteiro
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#142B4A] tracking-tight">
            Este material foi pensado para quem...
          </h2>
          <p className="mt-2 text-sm sm:text-base text-[#416A98]">
            Uma abordagem didática, acolhedora e acessível para diferentes situações.
          </p>

          {/* Dynamic Scroll Indicator Pills with dedicated active phases */}
          {!reducedMotion && (
            <div className="flex items-center justify-center gap-2 mt-4 text-xs font-bold">
              <span 
                className={`px-3.5 py-1 rounded-full transition-all duration-300 ${
                  progress < 0.35 
                    ? 'bg-[#142B4A] text-white shadow-xs scale-105' 
                    : 'bg-[#DCEBFA]/70 text-[#142B4A]'
                }`}
              >
                1. Quem ronca
              </span>
              <span 
                className={`px-3.5 py-1 rounded-full transition-all duration-300 ${
                  progress >= 0.35 && progress < 0.70 
                    ? 'bg-[#142B4A] text-white shadow-xs scale-105' 
                    : 'bg-[#DCEBFA]/70 text-[#142B4A]'
                }`}
              >
                2. Divide o quarto
              </span>
              <span 
                className={`px-3.5 py-1 rounded-full transition-all duration-300 ${
                  progress >= 0.70 
                    ? 'bg-[#142B4A] text-white shadow-xs scale-105' 
                    : 'bg-[#DCEBFA]/70 text-[#142B4A]'
                }`}
              >
                3. Casais
              </span>
            </div>
          )}
        </div>

        {/* Stacked Cards Area */}
        <div className="relative max-w-2xl mx-auto h-[320px] sm:h-[350px]">
          {CARDS.map((card) => {
            const Icon = card.icon;
            const style = getCardStyle(card.id);

            return (
              <div
                key={card.id}
                style={style}
                onClick={() => setActiveCardId(activeCardId === card.id ? null : card.id)}
                className={`w-full bg-white rounded-3xl p-6 sm:p-7 border-2 border-[#DCEBFA] shadow-lg hover:shadow-2xl transition-shadow cursor-pointer select-none ${
                  reducedMotion ? 'relative mb-6' : 'absolute top-0 left-0 right-0'
                }`}
              >
                {/* Card Header (Always visible when stacked) */}
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-[#DCEBFA] text-[#142B4A] flex items-center justify-center shrink-0 shadow-xs ring-4 ring-[#DCEBFA]/40">
                      <Icon className="w-6 h-6 text-[#142B4A]" />
                    </div>
                    <div>
                      <span className="text-[11px] font-black uppercase tracking-wider text-[#416A98]">
                        Situação {card.tag}
                      </span>
                      <h3 className="font-extrabold text-[#142B4A] text-lg sm:text-xl leading-tight">
                        {card.title}
                      </h3>
                    </div>
                  </div>

                  <span className="hidden sm:inline-block text-[11px] font-bold text-[#142B4A] bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
                    {card.badge}
                  </span>
                </div>

                {/* Card Description */}
                <p className="text-sm sm:text-base text-[#416A98] leading-relaxed pt-1 border-t border-slate-100">
                  {card.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Action Button right below stacked cards */}
        <div className="mt-8 sm:mt-10 text-center">
          <button
            onClick={scrollToOffer}
            className="btn-pill-green text-base sm:text-lg px-9 sm:px-12 py-4.5 shadow-xl hover:shadow-2xl inline-flex items-center justify-center gap-2 w-full sm:w-auto min-w-[280px]"
          >
            <span>Quero conhecer o material</span>
            <ChevronDown className="w-5 h-5 shrink-0" />
          </button>
        </div>

      </div>
    </section>
  );
};
